import models.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        School school = new School();

        // Read and add students
        readDataFromFile("students.txt", school, true);

        // Read and add teachers
        readDataFromFile("teachers.txt", school, false);

        // Print all members
        System.out.println(school);
    }

    // Helper method to read data from files and add to the school
    private static void readDataFromFile(String fileName, School school, boolean isStudent) throws FileNotFoundException {
        File file = new File(fileName);
        Scanner scanner = new Scanner(file);

        while (scanner.hasNextLine()) {
            String[] data = scanner.nextLine().split(" ");
            String name = data[0];
            String surname = data[1];
            int age = Integer.parseInt(data[2]);
            boolean gender = data[3].equalsIgnoreCase("Male");

            if (isStudent) {
                // For students
                Student student = new Student(name, surname, age, gender);
                for (int i = 4; i < data.length; i++) {
                    student.addGrade(Integer.parseInt(data[i]));
                }
                school.addMember(student);
            } else {
                // For teachers
                String subject = data[4];
                int experience = Integer.parseInt(data[5]);
                int salary = Integer.parseInt(data[6]);
                Teacher teacher = new Teacher(name, surname, age, gender, subject, experience, salary);
                if (experience > 10) teacher.giveRaise(10);
                school.addMember(teacher);
            }
        }
        scanner.close();
    }
}